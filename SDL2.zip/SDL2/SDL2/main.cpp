#include <stdio.h>
#define __STDC_CONSTANT_MACROS
#pragma comment(lib, "legacy_stdio_definitions.lib")
#pragma comment(lib, "SDL2.lib")
#pragma comment(lib, "SDL2main.lib")
extern "C"
{
	FILE __iob_func[3] = { *stdin, *stdout, *stderr };
}
extern "C"
{
#include "include/SDL2/SDL.h"
}


int main(int argc, char* argv[])
{
	if (SDL_Init(SDL_INIT_VIDEO)) {
		printf("Could not initialize SDL - %s\n", SDL_GetError());
	}
	else {
		printf("Success init SDL");
	}
	return 0;
}